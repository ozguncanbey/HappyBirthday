using Microsoft.AspNetCore.Mvc;

namespace HBDWebAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class BirthDaysController: ControllerBase
    {
        static List<Person> people = new List<Person> {
            new Person{fullname="Can",birthday="02/10/2002",category="Family"},
            new Person{fullname="Beydili",birthday="28/11/2003",category="Family"},
            new Person{fullname="Özgün",birthday="09/07/2002",category="Friend"}
        };
        [HttpGet]
        public List<Person> Get() {
            
            return people;
        }

        [HttpPost]
        public Person Post(Person person) {
            people.Add(person);
            return person;
        }
    }
}