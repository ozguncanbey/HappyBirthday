namespace HBDWebAPI 
{
    public class Person
    {
        public string fullname { get; set; }
        public string birthday { get; set; }
        public string category { get; set; }
    }
}